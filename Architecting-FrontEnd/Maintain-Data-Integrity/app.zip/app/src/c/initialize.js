/**
 * @fileOverview  Defining the main namespace and its MVC sub-namespaces
 * @author Gerd Wagner
 */
// main namespace vt = "Vocabulary Training"
var vt = { m:{}, v:{}, c:{} };
